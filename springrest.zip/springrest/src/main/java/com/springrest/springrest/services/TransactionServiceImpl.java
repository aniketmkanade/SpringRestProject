package com.springrest.springrest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.dao.TransactionDao;
import com.springrest.springrest.entity.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    private TransactionDao transactionDao;

    // Default constructor
    public TransactionServiceImpl() {
    }

    @Override
    public List<Transaction> getTransactions() {
        // Retrieve all transactions from the database
        return transactionDao.findAll();
    }

    @Override
    public Transaction getTransaction(int transactionId) {
        // Retrieve a single transaction by its ID
        return transactionDao.getOne(transactionId);
    }

    @Override
    public Transaction addTransaction(Transaction transaction) {
        // Save a new transaction to the database
        transactionDao.save(transaction);
        return transaction;
    }

    @Override
    public Transaction updateTransaction(Transaction newTransaction) {
        // Update an existing transaction in the database
        // If the transaction with the same ID exists, it will be updated
        transactionDao.save(newTransaction);
        return newTransaction;
    }

    @Override
    public void deleteTransaction(int id) {
        // Delete a transaction by its ID
        Transaction entity = transactionDao.getOne(id);
        transactionDao.delete(entity);
    }
}
