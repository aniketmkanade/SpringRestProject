package com.springrest.springrest.services;

import java.util.List;

import com.springrest.springrest.entity.Transaction;

public interface TransactionService {
	
	public List<Transaction> getTransactions();

	public Transaction getTransaction(int parseLong);

	public Transaction addTransaction(Transaction transaction);

	public Transaction updateTransaction(Transaction transaction);

	public void deleteTransaction(int parseLong);
	
}
