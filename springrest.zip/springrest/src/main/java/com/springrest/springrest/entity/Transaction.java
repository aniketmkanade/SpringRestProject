package com.springrest.springrest.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Transaction {

    @Id
    private int id;
    private String timestamp;
    private String type;
    private String actor;
    private String transactionData;

    // Constructor with parameters
    public Transaction(int id, String timestamp, String type, String actor, String transactionData) {
        super();
        this.id = id;
        this.timestamp = timestamp;
        this.type = type;
        this.actor = actor;
        this.transactionData = transactionData;
    }

    // Default constructor
    public Transaction() {
        super();
    }

    // Getter and setter methods for each field
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getTransactionData() {
        return transactionData;
    }

    public void setTransactionData(String transactionData) {
        this.transactionData = transactionData;
    }

    // Override toString method for easy debugging
    @Override
    public String toString() {
        return "Transaction [id=" + id + ", timestamp=" + timestamp + ", type=" + type + ", actor=" + actor
                + ", transactionData=" + transactionData + "]";
    }
}
