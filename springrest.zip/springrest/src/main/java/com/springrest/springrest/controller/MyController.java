package com.springrest.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.springrest.springrest.entity.Transaction;
import com.springrest.springrest.services.TransactionService;

@RestController
public class MyController {
    
    @Autowired
    private TransactionService transactionService;

    // Endpoint to welcome message
    @GetMapping("/home")
    public String home() {
        return "Welcome to the application";
    }

    // Get the list of transactions
    @GetMapping("/transactions")
    public List<Transaction> getTransactions() {
        return this.transactionService.getTransactions();
    }

    // Get a single transaction by ID
    @GetMapping("/transactions/{transactionId}")
    public Transaction getTransaction(@PathVariable String transactionId) {
        return this.transactionService.getTransaction(Integer.parseInt(transactionId));
    }

    // Add a new transaction
    @PostMapping("/transactions")
    public Transaction addTransaction(@RequestBody Transaction transaction) {
        return this.transactionService.addTransaction(transaction);
    }

    // Update an existing transaction
    @PutMapping("/transactions")
    public Transaction updateTransaction(@RequestBody Transaction transaction) {
        return this.transactionService.updateTransaction(transaction);
    }

    // Delete a transaction by ID
    @DeleteMapping("/transactions/{transactionId}")
    public ResponseEntity<HttpStatus> deleteTransaction(@PathVariable String transactionId) {
        try {
            this.transactionService.deleteTransaction(Integer.parseInt(transactionId));
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
