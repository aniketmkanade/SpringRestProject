package com.springrest.springrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.springrest.springrest.entity.Transaction;

// This interface extends JpaRepository, which provides CRUD operations for Transaction entities.
// The entity type is Transaction, and the primary key type is Integer.
public interface TransactionDao extends JpaRepository<Transaction, Integer> {
}
